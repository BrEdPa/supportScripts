
##run installers
@echo off
start "" /w /b "C:\TEMP\driversFor_fi8170\PSIPISIS-fi-8000_Series-3_10_0.exe"
start "" /w /b "C:\TEMP\driversFor_fi8170\PSIPTWAIN-3_10_0.exe"
start "" /w /b "C:\TEMP\driversFor_fi8170\WinFR4SSV55_1303_11.exe"